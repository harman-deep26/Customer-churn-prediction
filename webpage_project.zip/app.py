from flask import Flask, request, render_template
import joblib
import numpy as np  # Added import

app = Flask(__name__)

# ============================
# Load model and features
# ============================
model = joblib.load("C:/Users/lenovo/OneDrive/Desktop/project/model/grid_xgb.best_estimator_ (1).pkl")

# Define the features in the order expected by the model
features = [
    "Partner",
    "Dependents",
    "tenure",
    "OnlineSecurity",
    "TechSupport",
    "Contract_Two year",
    "InternetService_Fiber optic",
    "InternetService_No",
    "MonthlyCharges",
    "TotalCharges"
]

@app.route('/')
def home():
    return render_template('index.html', prediction_text=None)

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get form values from HTML form
        data = {
            "Partner": 1 if request.form['Partner'] == "Yes" else 0,
            "Dependents": 1 if request.form['Dependents'] == "Yes" else 0,
            "tenure": float(request.form['tenure']),
            "OnlineSecurity": 1 if request.form['OnlineSecurity'] == "Yes" else 0,
            "TechSupport": 1 if request.form['TechSupport'] == "Yes" else 0,
            "Contract_Two year": 1 if request.form['Contract'] == "Two year" else 0,
            "InternetService_Fiber optic": 1 if request.form['InternetService'] == "Fiber optic" else 0,
            "InternetService_No": 1 if request.form['InternetService'] == "No" else 0,
            "MonthlyCharges": float(request.form['MonthlyCharges']),
            "TotalCharges": float(request.form['TotalCharges'])
        }

        # Convert input data into a 2D array for the model
        input_data = np.array([[data[feature] for feature in features]])
        
        # Make prediction
        prediction = model.predict(input_data)[0]
        probability = model.predict_proba(input_data)[0][1]  # Churn probability

        # Prepare result
        if prediction == 1:
            result = f"⚠️ High Churn Risk ({probability:.2%})"
            color = "red"
        else:
            result = f"✅ Low Churn Risk ({probability:.2%})"
            color = "green"

        return render_template('index.html', prediction_text=result, prediction_color=color)

    except Exception as e:
        return render_template('index.html', prediction_text=f"Error: {e}", prediction_color="gray")

if __name__ == "__main__":
    app.run(debug=True)
